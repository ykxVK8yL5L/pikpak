# -*- coding: utf-8 -*-
# Module: default
# Author: Roman V. M.
# Created on: 28.11.2014
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html


import time
import requests
import base64
import json
import sys
from urllib.parse import urlencode
from urllib.parse import urlparse, parse_qs,parse_qsl
import xbmcgui
import xbmcplugin
from xbmcswift2 import Plugin


# Get the plugin url in plugin:// notation.
_URL = sys.argv[0]
# Get the plugin handle as an integer number.
_HANDLE = int(sys.argv[1])




plugin = Plugin()
headers = {'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/27.0.1453.93 Safari/537.36'}
def get_url(**kwargs):
    return '{}?{}'.format(_URL, urlencode(kwargs))
def get_files(path, pageno):
    user = plugin.get_storage('user')
    if 'access_token' not in user.keys():
        dialog = xbmcgui.Dialog()
        ok = dialog.ok('错误提示', '未登陆或Token过期,请登陆')
        return 
    ucookies = user['access_token'] 
    rdata = {'parent_id': path,'page_token': pageno}
    url = 'https://api-drive.mypikpak.com/drive/v1/files?parent_id='+path+'&page_token='+pageno
    headers['referer'] = "https://api-drive.mypikpak.com/drive/v1/files"
    headers['Authorization']='Bearer '+ucookies
    try:
        r = requests.get(url, verify=False,data=rdata, headers=headers, timeout=40)
    except:
        return 'error'
    else:
        result = json.loads(r.text)
        if result['files'] is None:
            return 'error'
    return json.dumps(result)

def login():
    s = requests.session()
    url = "https://user.mypikpak.com/v1/auth/signin"
    user = plugin.get_storage('user')
    username = user['username']
    password = user['password']
    d = json.dumps({
    "captcha_token": "",
    "client_id": "YNxT9w7GMdWvEOKa",
    "client_secret": "dbw2OtmVEeuUvIptb1Coyg",
    "username": username,
    "password": password
    })
    r = s.post(url, verify=False, data=d)
    result = json.loads(r.text)
    if result['access_token'] is None:
        dialog = xbmcgui.Dialog()
        ok = dialog.ok('错误提示', '登陆错误，请检查用户名密码或稍后再试')
    else:
        user['access_token'] = result['access_token']
        user.sync()
        dialog = xbmcgui.Dialog()
        ok = dialog.ok('错误提示', '登陆成功!!')
    return 


def username():
    keyboard = xbmc.Keyboard('', '请输入用户名')
    xbmc.sleep(1500)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        username = keyboard.getText()
        user = plugin.get_storage('user')
        user['username'] = username
        user.sync()
        return


def password():
    user = plugin.get_storage('user')
    if 'username' not in user.keys():
        dialog = xbmcgui.Dialog()
        ok = dialog.ok('错误提示', '请先设置用户名[邮箱]')
        return
    keyboard = xbmc.Keyboard('', '请输入密码-会明文保存')
    xbmc.sleep(1500)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        password = keyboard.getText()
        #m1 = md5.new()
        #m1.update(password.encode(encoding='utf-8'))
        #m1.hexdigest()
        #user['password'] = 
        user['password'] = password
        user.sync()
        return



def play(path):
    user = plugin.get_storage('user')
    if 'access_token' not in user.keys():
        dialog = xbmcgui.Dialog()
        ok = dialog.ok('错误提示', '未登陆或Token过期,请登陆')
    ucookies = user['access_token'] 
    url = 'https://api-drive.mypikpak.com/drive/v1/files/'+path
    headers['referer'] = "https://api-drive.mypikpak.com/drive/v1/files"
    headers['Authorization']='Bearer '+ucookies
    try:
        r = requests.get(url, verify=False, headers=headers, timeout=40)
    except:
        return 'error'
    else:
        result = json.loads(r.text)
        # xbmcplugin.setPluginCategory(_HANDLE, 'Pikpak')
        # xbmcplugin.setContent(_HANDLE, 'Pikpak')
        if result['medias'] is None:
            dialog = xbmcgui.Dialog()
            ok = dialog.ok('错误提示', '未打到任何可播放的文件')
            return
        medias = result['medias']
        for media in medias:
            list_item = xbmcgui.ListItem(label=media['media_name'])
            list_item.setInfo('video', {'title': media['media_name'],'genre': 'Pikpak','mediatype': 'video'})
            list_item.setProperty('IsPlayable', 'true')
            url = get_url(action='playvideo', video=media['link']['url'])
            is_folder = False
            xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
        #xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.endOfDirectory(_HANDLE)


def play_video(path):
    play_item = xbmcgui.ListItem(path=path)
    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=play_item)
    
    
def list_dir(path):
    filesresult = json.loads(get_files(path, ''))
    # xbmcplugin.setPluginCategory(_HANDLE, 'Pikpak')
    # xbmcplugin.setContent(_HANDLE, 'Pikpak')
    files = filesresult['files']
    for file in files:
        if file['kind'] == 'drive#folder':
            list_item = xbmcgui.ListItem(label=file['name'])
            url = get_url(action='list_dir', path=file['id'].encode("utf-8"))
            is_folder = True
            xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
        elif 'video' in file['mime_type'] or 'audio' in file['mime_type']:
            list_item = xbmcgui.ListItem(label=file['name'])
            url = get_url(action='play', path=file['id'].encode("utf-8"))
            is_folder = True
            xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
        else:
            list_item = xbmcgui.ListItem(label=file['name'])
            url = get_url(action='none', path=file['id'].encode("utf-8"))
            is_folder = True
            xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)

    if filesresult['next_page_token'] != '':
        list_item = xbmcgui.ListItem(label='下一页')
        url = get_url(action='list_dir_next', path=path,page=filesresult['next_page_token'])
        is_folder = True
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    #xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_HANDLE)




def list_dir_next(path, page):
    filesresult = json.loads(get_files(path, page))
    files = filesresult['files']
    # xbmcplugin.setPluginCategory(_HANDLE, 'Pikpak')
    # xbmcplugin.setContent(_HANDLE, 'Pikpak')
    for file in files:
        if file['kind'] == 'drive#folder':
            list_item = xbmcgui.ListItem(label=file['name'])
            url = get_url(action='list_dir', path=file['id'].encode("utf-8"))
            is_folder = True
            xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
        elif 'video' in file['mime_type'] or 'audio' in file['mime_type']:
            list_item = xbmcgui.ListItem(label=file['name'])
            url = get_url(action='play', path=file['id'].encode("utf-8"))
            is_folder = True
            xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
        else:
            list_item = xbmcgui.ListItem(label=file['name'])
            url = get_url(action='none', path=file['id'].encode("utf-8"))
            is_folder = True
            xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)

    if filesresult['next_page_token'] != '':
        list_item = xbmcgui.ListItem(label='下一页')
        url = get_url(action='list_dir_next', path=path,page=filesresult['next_page_token'])
        is_folder = True
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    #xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_HANDLE)



def list_home():
    filesresult = json.loads(get_files('', ''))
    # xbmcplugin.setPluginCategory(_HANDLE, 'Pikpak')
    # xbmcplugin.setContent(_HANDLE, 'Pikpak')
    files = filesresult['files']
    for file in files:
        if file['kind'] == 'drive#folder':
            list_item = xbmcgui.ListItem(label=file['name'])
            url = get_url(action='list_dir', path=file['id'].encode("utf-8"))
            is_folder = True
            xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
        elif 'video' in file['mime_type'] or 'audio' in file['mime_type']:
            list_item = xbmcgui.ListItem(label=file['name'])
            url = get_url(action='play', path=file['id'].encode("utf-8"))
            is_folder = True
            xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
        else:
            list_item = xbmcgui.ListItem(label=file['name'])
            url = get_url(action='none', path=file['id'].encode("utf-8"))
            is_folder = True
            xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    
    if filesresult['next_page_token'] != '':
        list_item = xbmcgui.ListItem(label='下一页')
        url = get_url(action='list_dir_next', path='',page=filesresult['next_page_token'])
        is_folder = True
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    #xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_HANDLE)
    




def get_categories():
    items = []
    items.append({
        'label': u'[COLOR yellow]/[/COLOR]',
        'action': 'list_home',
    })
    items.append({
        'label': u'[COLOR yellow]设置用户名[/COLOR]',
        'action': 'username',
    })
    items.append({
        'label': u'[COLOR yellow]设置密码[/COLOR]',
        'action': 'password',
    })

    items.append({
        'label': u'[COLOR red]登陆[/COLOR]',
        'action': 'login',
    })
    return items

def list_categories():
    # xbmcplugin.setPluginCategory(_HANDLE, 'Pikpak')
    # xbmcplugin.setContent(_HANDLE, 'Pikpak')
    categories = get_categories()
    for category in categories:
        list_item = xbmcgui.ListItem(label=category['label'])
        url = get_url(action=category['action'])
        is_folder = True
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, is_folder)
    #xbmcplugin.addSortMethod(_HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(_HANDLE)

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params['action'] == 'username':
            username()
        elif params['action'] == 'password':
            password()
        elif params['action'] == 'login': 
            login()
        elif params['action'] == 'play': 
            play(params['path'])
        elif params['action'] == 'playvideo': 
            play_video(params['video'])
        elif params['action'] == 'list_dir': 
            list_dir(params['path'])
        elif params['action'] == 'list_dir_next': 
            list_dir_next(params['path'],params['page'])
        elif params['action'] == 'none': 
            dialog = xbmcgui.Dialog()
            ok = dialog.ok('错误提示', '不支持的文件类型')
        elif params['action'] == 'list_home':
            list_home()
    else:
        list_categories()


if __name__ == '__main__':
    router(sys.argv[2][1:])
